import React, { useEffect, useMemo, useRef } from 'react'
import * as d3 from 'd3'

export default function Chart({ subToMains, onSelectSub }){
  const svgRef = useRef()
  const wrapRef = useRef()

  const entries = useMemo(()=>{
    const arr = Object.entries(subToMains || {}).filter(([s, arr]) => (arr?.length || 0) > 1)
    arr.sort((a,b)=> (b[1].length - a[1].length) || a[0].localeCompare(b[0]))
    return arr.map(d => ({ name: d[0], count: d[1].length }))
  }, [subToMains])

  const render = () => {
    const svgEl = svgRef.current
    const svg = d3.select(svgEl)
    const width = Math.max(700, Math.floor(wrapRef.current?.getBoundingClientRect().width || 700))
    const height = 380
    svg.selectAll('*').remove()

    const empty = document.getElementById('chartEmpty')
    if (!entries.length){
      if (empty) empty.hidden = false
      return
    } else {
      if (empty) empty.hidden = true
    }

    const margin = { top: 20, right: 20, bottom: 100, left: 60 }
    const innerW = width - margin.left - margin.right
    const innerH = height - margin.top - margin.bottom

    svgEl.setAttribute('viewBox', \`0 0 \${width} \${height}\`)

    const x = d3.scaleBand().domain(entries.map(d=>d.name)).range([margin.left, margin.left + innerW]).padding(0.2)
    const y = d3.scaleLinear().domain([0, d3.max(entries, d=>d.count)]).nice().range([margin.top + innerH, margin.top])

    svg.append('g').attr('class','axis x').attr('transform', \`translate(0, \${margin.top + innerH})\`)
      .call(d3.axisBottom(x))
      .selectAll('text').attr('transform','rotate(-40)').style('text-anchor','end')

    svg.append('g').attr('class','axis y').attr('transform', \`translate(\${margin.left}, 0)\`)
      .call(d3.axisLeft(y).ticks(5).tickFormat(d3.format('d')))

    svg.selectAll('.bar').data(entries).enter().append('rect')
      .attr('class', 'bar')
      .attr('x', d=>x(d.name))
      .attr('y', d=>y(d.count))
      .attr('width', x.bandwidth())
      .attr('height', d=> (margin.top + innerH) - y(d.count))
      .style('cursor','pointer')
      .on('click', (_, d) => onSelectSub?.(d.name))

    svg.selectAll('.bar-label').data(entries).enter().append('text')
      .attr('class','bar-label')
      .attr('x', d=>x(d.name) + x.bandwidth()/2)
      .attr('y', d=>y(d.count) - 6)
      .attr('text-anchor','middle')
      .text(d=>d.count)
  }

  useEffect(render, [entries, onSelectSub])

  useEffect(()=>{
    const ro = new ResizeObserver(render)
    if (wrapRef.current) ro.observe(wrapRef.current)
    return ()=> ro.disconnect()
  }, [])

  return (
    <div className="chart" ref={wrapRef}>
      <svg ref={svgRef} width="100%" height="380" role="img" aria-label="Bar chart of shared subcomponents"></svg>
    </div>
  )
}
